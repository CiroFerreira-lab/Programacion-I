import json
import os

CARPETA = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(CARPETA, "inscriptos.json")


class Nodo:
    def __init__(self, nombre, categoria):
        self.nombre = nombre
        self.categoria = categoria
        self.izquierdo = None
        self.derecho = None


def insertar(raiz, nombre, categoria):
    if raiz is None:
        return Nodo(nombre, categoria)
    if nombre.lower() < raiz.nombre.lower():
        raiz.izquierdo = insertar(raiz.izquierdo, nombre, categoria)
    elif nombre.lower() > raiz.nombre.lower():
        raiz.derecho = insertar(raiz.derecho, nombre, categoria)
    return raiz


def buscar(raiz, nombre, comparaciones=0):
    if raiz is None:
        return None, comparaciones
    comparaciones += 1
    if nombre.lower() == raiz.nombre.lower():
        return raiz, comparaciones
    if nombre.lower() < raiz.nombre.lower():
        return buscar(raiz.izquierdo, nombre, comparaciones)
    return buscar(raiz.derecho, nombre, comparaciones)


def mostrar_orden(raiz):
    if raiz is not None:
        mostrar_orden(raiz.izquierdo)
        print(raiz.nombre, "-", raiz.categoria)
        mostrar_orden(raiz.derecho)


def altura(raiz):
    if raiz is None:
        return -1
    izq = altura(raiz.izquierdo)
    der = altura(raiz.derecho)
    if izq > der:
        return izq + 1
    return der + 1


def guardar_json(lista):
    with open(ARCHIVO, "w", encoding="utf-8") as archivo:
        json.dump(lista, archivo, indent=4, ensure_ascii=False)


def cargar_json():
    if not os.path.exists(ARCHIVO):
        iniciales = [
            {"nombre":"Martin Gomez","categoria":"5ª"},
            {"nombre":"Lucas Peralta","categoria":"5ª"},
            {"nombre":"Sofia Ruiz","categoria":"4ª"},
            {"nombre":"Diego Acosta","categoria":"6ª"},
            {"nombre":"Valentina Sosa","categoria":"4ª"},
            {"nombre":"Tomas Benitez","categoria":"5ª"},
            {"nombre":"Camila Diaz","categoria":"6ª"},
            {"nombre":"Facundo Romero","categoria":"4ª"},
            {"nombre":"Julieta Molina","categoria":"6ª"},
            {"nombre":"Nicolas Ortiz","categoria":"5ª"},
            {"nombre":"Agustina Lopez","categoria":"4ª"},
            {"nombre":"Bruno Fernandez","categoria":"6ª"}
        ]
        guardar_json(iniciales)

    with open(ARCHIVO, "r", encoding="utf-8") as archivo:
        return json.load(archivo)


def cargar_arbol(lista):
    raiz = None
    for jugador in lista:
        raiz = insertar(raiz, jugador["nombre"], jugador["categoria"])
    return raiz


def opcion_buscar(raiz):
    nombre = input("Nombre del jugador: ").strip()
    jugador, cantidad = buscar(raiz, nombre)
    if jugador is None:
        print("Jugador no inscripto.")
    else:
        print("Categoría:", jugador.categoria)
    print("Comparaciones realizadas:", cantidad)


def opcion_agregar(raiz, lista):
    nombre = input("Nombre del nuevo jugador: ").strip()
    categoria = input("Categoría (4ª, 5ª o 6ª): ").strip()
    if nombre == "" or categoria == "":
        print("Completá el nombre y la categoría.")
        return raiz, lista

    jugador, cantidad = buscar(raiz, nombre)
    if jugador is not None:
        print("Ese jugador ya está inscripto.")
        return raiz, lista

    antes = altura(raiz)
    raiz = insertar(raiz, nombre, categoria)
    lista.append({"nombre": nombre, "categoria": categoria})
    guardar_json(lista)
    despues = altura(raiz)

    print("Jugador agregado y guardado correctamente.")
    print("Altura antes:", antes)
    print("Altura después:", despues)
    print("Archivo:", ARCHIVO)
    return raiz, lista


class Partido:
    def __init__(self, nombre, izquierdo=None, derecho=None):
        self.nombre = nombre
        self.izquierdo = izquierdo
        self.derecho = derecho
        self.ganador = ""


def pedir_ganador(partido):
    if partido.izquierdo.izquierdo is None:
        equipo1 = partido.izquierdo.nombre
    else:
        equipo1 = partido.izquierdo.ganador

    if partido.derecho.izquierdo is None:
        equipo2 = partido.derecho.nombre
    else:
        equipo2 = partido.derecho.ganador

    print("\nPartido:", equipo1, "vs", equipo2)
    ganador = input("Escribí el ganador: ").strip()
    while ganador.lower() != equipo1.lower() and ganador.lower() != equipo2.lower():
        print("Ingresá uno de los dos equipos.")
        ganador = input("Ganador: ").strip()
    partido.ganador = ganador


def jugar_torneo():
    a = Partido("Las Leonas")
    b = Partido("Doble Falta")
    c = Partido("Los Tanos")
    d = Partido("Los Primos")
    semi1 = Partido("Semifinal 1", a, b)
    semi2 = Partido("Semifinal 2", c, d)
    final = Partido("Final", semi1, semi2)

    print("\nSEMIFINAL 1")
    pedir_ganador(semi1)
    print("\nSEMIFINAL 2")
    pedir_ganador(semi2)
    print("\nFINAL")
    pedir_ganador(final)
    print("\nCampeón:", final.ganador)


def mostrar_orden_partidos():
    a = Partido("Las Leonas")
    b = Partido("Doble Falta")
    c = Partido("Los Tanos")
    d = Partido("Los Primos")
    semi1 = Partido("Semifinal 1", a, b)
    semi2 = Partido("Semifinal 2", c, d)
    final = Partido("Final", semi1, semi2)

    # En postorden se muestran primero las semifinales y al final la final.
    def postorden(nodo):
        if nodo is not None:
            postorden(nodo.izquierdo)
            postorden(nodo.derecho)
            if nodo.izquierdo is not None:
                print(nodo.nombre)

    print("\nOrden de los partidos:")
    postorden(final)


def menu():
    lista = cargar_json()
    raiz = cargar_arbol(lista)

    while True:
        print("\n===== SISTEMA DEL TORNEO =====")
        print("1. Buscar jugador")
        print("2. Mostrar jugadores en orden alfabético")
        print("3. Agregar jugador")
        print("4. Jugar torneo")
        print("5. Mostrar orden de los partidos")
        print("6. Salir")
        opcion = input("Elegí una opción: ").strip()

        if opcion == "1":
            opcion_buscar(raiz)
        elif opcion == "2":
            mostrar_orden(raiz)
        elif opcion == "3":
            raiz, lista = opcion_agregar(raiz, lista)
        elif opcion == "4":
            jugar_torneo()
        elif opcion == "5":
            mostrar_orden_partidos()
        elif opcion == "6":
            print("Programa finalizado.")
            break
        else:
            print("Opción incorrecta.")


menu()
